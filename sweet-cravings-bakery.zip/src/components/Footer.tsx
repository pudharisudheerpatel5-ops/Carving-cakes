import { Cake, Instagram, Facebook, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-bakery-brown text-bakery-cream pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="bg-bakery-pink p-2 rounded-xl">
                <Cake className="text-bakery-brown w-6 h-6" />
              </div>
              <span className="font-display text-2xl font-bold tracking-tight">
                Sweet Cravings
              </span>
            </div>
            <p className="text-bakery-cream/60 leading-relaxed">
              Baking moments of pure joy since 2020. Your local home-based bakery for all things sweet.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-bakery-cream/10 rounded-full flex items-center justify-center hover:bg-bakery-pink hover:text-bakery-brown transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-bakery-cream/10 rounded-full flex items-center justify-center hover:bg-bakery-pink hover:text-bakery-brown transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-bakery-cream/10 rounded-full flex items-center justify-center hover:bg-bakery-pink hover:text-bakery-brown transition-all">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-display text-xl font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-bakery-cream/60">
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Home</a></li>
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Our Menu</a></li>
              <li><a href="#" className="hover:text-bakery-pink transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-xl font-bold mb-6">Categories</h4>
            <ul className="space-y-4 text-bakery-cream/60">
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Custom Cakes</a></li>
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Cupcakes</a></li>
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Wedding Cakes</a></li>
              <li><a href="#" className="hover:text-bakery-pink transition-colors">Party Boxes</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-xl font-bold mb-6">Newsletter</h4>
            <p className="text-bakery-cream/60 mb-6">Get sweet updates and special offers.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Your email"
                className="bg-bakery-cream/10 border border-bakery-cream/20 rounded-xl px-4 py-2 w-full focus:outline-none focus:border-bakery-pink"
              />
              <button className="bg-bakery-pink text-bakery-brown px-4 py-2 rounded-xl font-bold hover:bg-bakery-pink-dark transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-bakery-cream/10 pt-10 text-center text-sm text-bakery-cream/40">
          <p>© 2024 Sweet Cravings Bakery. All rights reserved.</p>
          <p className="mt-2">Made with ❤️ for dessert lovers.</p>
        </div>
      </div>
    </footer>
  );
}

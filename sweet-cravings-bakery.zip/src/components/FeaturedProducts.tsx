import React from 'react';
import { motion } from 'motion/react';
import { PRODUCTS } from '../constants';
import ProductCard from './ProductCard';
import { Product } from '../types';

interface FeaturedProductsProps {
  onOrder: (product: Product) => void;
}

export default function FeaturedProducts({ onOrder }: FeaturedProductsProps) {
  const featured = PRODUCTS.filter(p => p.tags?.includes('Best Seller') || p.tags?.includes('Popular'));

  return (
    <section className="py-20 bg-white/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display mb-4 text-bakery-brown"
          >
            Our Signature Creations
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-bakery-brown/60 max-w-2xl mx-auto"
          >
            Handpicked favorites that our customers can't get enough of. 
            Freshly baked every single day.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} onOrder={onOrder} />
          ))}
        </div>
      </div>
    </section>
  );
}

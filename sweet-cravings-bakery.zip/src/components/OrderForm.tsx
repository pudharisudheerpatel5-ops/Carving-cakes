import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Send, CheckCircle2 } from 'lucide-react';
import { Product } from '../types';

interface OrderFormProps {
  selectedProduct?: Product;
}

export default function OrderForm({ selectedProduct }: OrderFormProps) {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-xl mx-auto py-24 text-center"
      >
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-8">
          <CheckCircle2 className="w-10 h-10 text-green-600" />
        </div>
        <h2 className="text-4xl font-display mb-4 text-bakery-brown">Order Received!</h2>
        <p className="text-bakery-brown/60 mb-8">
          Thank you for choosing Sweet Cravings. We'll contact you on WhatsApp shortly to confirm your order details.
        </p>
        <button 
          onClick={() => setIsSubmitted(false)}
          className="bakery-button"
        >
          Place Another Order
        </button>
      </motion.div>
    );
  }

  return (
    <section className="py-24 bg-bakery-cream">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-display mb-4 text-bakery-brown">Place Your Order</h2>
          <p className="text-bakery-brown/60">Fill in the details and we'll handle the rest</p>
        </div>

        <motion.form 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmit}
          className="bg-white p-8 md:p-12 rounded-[3rem] shadow-xl border border-bakery-pink"
        >
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-bakery-brown uppercase tracking-wider">Full Name</label>
              <input 
                required
                type="text" 
                placeholder="Your Name"
                className="w-full px-6 py-4 rounded-2xl bg-bakery-cream/50 border border-bakery-pink focus:outline-none focus:border-bakery-brown transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-bakery-brown uppercase tracking-wider">Phone Number</label>
              <input 
                required
                type="tel" 
                placeholder="WhatsApp Number"
                className="w-full px-6 py-4 rounded-2xl bg-bakery-cream/50 border border-bakery-pink focus:outline-none focus:border-bakery-brown transition-colors"
              />
            </div>
          </div>

          <div className="space-y-2 mb-8">
            <label className="text-sm font-bold text-bakery-brown uppercase tracking-wider">Cake Type / Item</label>
            <select 
              defaultValue={selectedProduct?.name || ""}
              className="w-full px-6 py-4 rounded-2xl bg-bakery-cream/50 border border-bakery-pink focus:outline-none focus:border-bakery-brown transition-colors appearance-none"
            >
              <option value="" disabled>Select an item</option>
              <option>Chocolate Truffle Cake</option>
              <option>Red Velvet Cake</option>
              <option>Vanilla Cupcakes</option>
              <option>Choco-chip Cupcakes</option>
              <option>Custom Theme Cake</option>
              <option>Photo Cake</option>
              <option>Assorted Cookies</option>
            </select>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-bakery-brown uppercase tracking-wider">Delivery Date</label>
              <input 
                required
                type="date" 
                className="w-full px-6 py-4 rounded-2xl bg-bakery-cream/50 border border-bakery-pink focus:outline-none focus:border-bakery-brown transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-bakery-brown uppercase tracking-wider">Weight / Quantity</label>
              <input 
                type="text" 
                placeholder="e.g. 1kg or 6 pieces"
                className="w-full px-6 py-4 rounded-2xl bg-bakery-cream/50 border border-bakery-pink focus:outline-none focus:border-bakery-brown transition-colors"
              />
            </div>
          </div>

          <div className="space-y-2 mb-10">
            <label className="text-sm font-bold text-bakery-brown uppercase tracking-wider">Special Instructions</label>
            <textarea 
              rows={4}
              placeholder="Any message on cake or dietary requirements (Eggless/Vegan)..."
              className="w-full px-6 py-4 rounded-2xl bg-bakery-cream/50 border border-bakery-pink focus:outline-none focus:border-bakery-brown transition-colors resize-none"
            />
          </div>

          <button 
            type="submit"
            className="w-full bakery-button flex items-center justify-center gap-3 py-5 text-lg"
          >
            <Send className="w-5 h-5" />
            Send Order Request
          </button>
        </motion.form>
      </div>
    </section>
  );
}

import React from 'react';
import { motion } from 'motion/react';
import { ShoppingCart, Heart } from 'lucide-react';
import { Product } from '../types';

export interface ProductCardProps {
  product: Product;
  onOrder: (product: Product) => void;
  key?: string | number;
}

export default function ProductCard({ product, onOrder }: ProductCardProps) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bakery-card group overflow-hidden"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <button className="p-2 bg-white/80 backdrop-blur-sm rounded-full text-bakery-brown hover:bg-bakery-pink transition-colors">
            <Heart className="w-4 h-4" />
          </button>
        </div>
        {product.tags && (
          <div className="absolute bottom-4 left-4 flex gap-2">
            {product.tags.map(tag => (
              <span key={tag} className="px-3 py-1 bg-bakery-brown/80 backdrop-blur-sm text-bakery-cream text-[10px] font-bold uppercase tracking-wider rounded-full">
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-display font-bold text-bakery-brown">{product.name}</h3>
          <span className="text-lg font-bold text-bakery-brown-light">₹{product.price}</span>
        </div>
        <p className="text-sm text-bakery-brown/60 mb-6 line-clamp-2">
          {product.description}
        </p>
        <button 
          onClick={() => onOrder(product)}
          className="w-full bakery-button-outline flex items-center justify-center gap-2 py-2 text-sm"
        >
          <ShoppingCart className="w-4 h-4" />
          Add to Order
        </button>
      </div>
    </motion.div>
  );
}

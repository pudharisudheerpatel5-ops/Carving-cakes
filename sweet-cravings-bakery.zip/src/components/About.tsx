import { motion } from 'motion/react';
import { Heart, Clock, Leaf, Wallet } from 'lucide-react';

const USPs = [
  {
    icon: Clock,
    title: 'Same-day Delivery',
    description: 'Craving something sweet? We deliver within hours across the city.'
  },
  {
    icon: Heart,
    title: 'Fully Customizable',
    description: 'Your vision, our creation. We make cakes exactly how you want them.'
  },
  {
    icon: Leaf,
    title: 'Eggless & Vegan',
    description: 'We offer delicious options for every dietary preference.'
  },
  {
    icon: Wallet,
    title: 'Student Friendly',
    description: 'Premium taste at prices that won\'t break your piggy bank.'
  }
];

export default function About() {
  return (
    <section className="py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="rounded-[4rem] overflow-hidden shadow-xl">
              <img 
                src="https://picsum.photos/seed/about-bakery/800/800" 
                alt="Our Bakery Story" 
                className="w-full h-auto"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 bg-bakery-brown text-bakery-cream p-8 rounded-3xl shadow-2xl max-w-xs hidden md:block">
              <p className="font-display text-2xl mb-2 italic">"Baking is love made visible."</p>
              <p className="text-sm opacity-80">— Our Founder</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-display mb-8 text-bakery-brown">
              The Story of <span className="text-bakery-brown-light">Sweet Cravings</span>
            </h2>
            <div className="space-y-6 text-lg text-bakery-brown/70 leading-relaxed">
              <p>
                What started as a small kitchen experiment in 2020 has grown into a beloved home-based bakery. 
                Our passion for perfection and eye for detail has helped us create thousands of smiles.
              </p>
              <p>
                We believe that every celebration, no matter how small, deserves a special treat. 
                That's why we use only the freshest, high-quality ingredients to ensure every bite is a memory.
              </p>
            </div>
          </motion.div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {USPs.map((usp, index) => (
            <motion.div
              key={usp.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 bg-white rounded-3xl border border-bakery-pink hover:border-bakery-brown transition-colors group"
            >
              <div className="w-12 h-12 bg-bakery-pink rounded-2xl flex items-center justify-center mb-6 group-hover:bg-bakery-brown transition-colors">
                <usp.icon className="text-bakery-brown group-hover:text-bakery-cream transition-colors" />
              </div>
              <h3 className="text-xl font-display font-bold mb-3 text-bakery-brown">{usp.title}</h3>
              <p className="text-sm text-bakery-brown/60 leading-relaxed">{usp.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PRODUCTS } from '../constants';
import ProductCard from './ProductCard';
import { Product } from '../types';

interface MenuProps {
  onOrder: (product: Product) => void;
}

export default function Menu({ onOrder }: MenuProps) {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const categories = ['All', 'Cakes', 'Cupcakes', 'Special Orders', 'Cookies'];

  const filteredProducts = activeCategory === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  return (
    <section className="py-24 bg-bakery-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-display mb-4 text-bakery-brown">Our Full Menu</h2>
          <p className="text-bakery-brown/60">Browse our collection of sweet treats</p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-16">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === cat 
                  ? 'bg-bakery-brown text-bakery-cream shadow-lg' 
                  : 'bg-white text-bakery-brown hover:bg-bakery-pink'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <motion.div 
          layout
          className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          <AnimatePresence mode='popLayout'>
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} onOrder={onOrder} />
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { Cake, Menu as MenuIcon, X, ShoppingBag } from 'lucide-react';
import { useState } from 'react';
import { Page } from '../types';

interface NavbarProps {
  currentPage: Page;
  onPageChange: (page: Page) => void;
}

export default function Navbar({ currentPage, onPageChange }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems: { label: string; value: Page }[] = [
    { label: 'Home', value: 'home' },
    { label: 'Menu', value: 'menu' },
    { label: 'About', value: 'about' },
    { label: 'Contact', value: 'contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-bakery-cream/80 backdrop-blur-md border-b border-bakery-pink">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => onPageChange('home')}
          >
            <div className="bg-bakery-brown p-2 rounded-xl">
              <Cake className="text-bakery-pink w-6 h-6" />
            </div>
            <span className="font-display text-2xl font-bold tracking-tight text-bakery-brown">
              Sweet Cravings
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.value}
                onClick={() => onPageChange(item.value)}
                className={`text-sm font-medium transition-colors hover:text-bakery-brown-light ${
                  currentPage === item.value ? 'text-bakery-brown border-b-2 border-bakery-brown' : 'text-bakery-brown/60'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button 
              onClick={() => onPageChange('order')}
              className="bakery-button flex items-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              Order Now
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-bakery-brown p-2"
            >
              {isMenuOpen ? <X /> : <MenuIcon />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-bakery-cream border-b border-bakery-pink"
        >
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.value}
                onClick={() => {
                  onPageChange(item.value);
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-3 py-4 text-base font-medium text-bakery-brown hover:bg-bakery-pink rounded-xl"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => {
                onPageChange('order');
                setIsMenuOpen(false);
              }}
              className="w-full mt-4 bakery-button flex items-center justify-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              Order Now
            </button>
          </div>
        </motion.div>
      )}
    </nav>
  );
}

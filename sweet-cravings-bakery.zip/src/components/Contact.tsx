import { motion } from 'motion/react';
import { Phone, Mail, MapPin, MessageCircle } from 'lucide-react';

export default function Contact() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl font-display mb-8 text-bakery-brown">Get in Touch</h2>
            <p className="text-lg text-bakery-brown/70 mb-12">
              Have a question or want to discuss a custom order? We're here to help! 
              Reach out to us through any of these channels.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-bakery-pink rounded-2xl flex items-center justify-center shrink-0">
                  <Phone className="text-bakery-brown" />
                </div>
                <div>
                  <h3 className="font-bold text-bakery-brown mb-1">Call Us</h3>
                  <p className="text-bakery-brown/60">+91 98765 43210</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-bakery-pink rounded-2xl flex items-center justify-center shrink-0">
                  <MessageCircle className="text-bakery-brown" />
                </div>
                <div>
                  <h3 className="font-bold text-bakery-brown mb-1">WhatsApp</h3>
                  <p className="text-bakery-brown/60">Chat with us instantly</p>
                  <a href="#" className="text-bakery-brown-light font-medium underline">Start Chat</a>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-bakery-pink rounded-2xl flex items-center justify-center shrink-0">
                  <Mail className="text-bakery-brown" />
                </div>
                <div>
                  <h3 className="font-bold text-bakery-brown mb-1">Email</h3>
                  <p className="text-bakery-brown/60">hello@sweetcravings.com</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-bakery-pink rounded-2xl flex items-center justify-center shrink-0">
                  <MapPin className="text-bakery-brown" />
                </div>
                <div>
                  <h3 className="font-bold text-bakery-brown mb-1">Location</h3>
                  <p className="text-bakery-brown/60">123 Bakery Lane, Sweet City, SC 456789</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="rounded-[3rem] overflow-hidden shadow-xl border-8 border-bakery-cream h-[500px]"
          >
            {/* Placeholder for Google Maps */}
            <div className="w-full h-full bg-bakery-pink flex items-center justify-center relative">
              <img 
                src="https://picsum.photos/seed/map/800/800?blur=2" 
                alt="Map Placeholder" 
                className="w-full h-full object-cover opacity-50"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white p-6 rounded-3xl shadow-2xl text-center">
                  <MapPin className="w-10 h-10 text-bakery-brown mx-auto mb-4" />
                  <p className="font-display font-bold text-xl text-bakery-brown">Visit Our Studio</p>
                  <p className="text-sm text-bakery-brown/60 mt-2">By appointment only</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

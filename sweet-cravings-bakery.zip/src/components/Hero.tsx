import { motion } from 'motion/react';
import { ArrowRight, Star } from 'lucide-react';
import { Page } from '../types';

interface HeroProps {
  onOrderClick: () => void;
}

export default function Hero({ onOrderClick }: HeroProps) {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 bg-bakery-pink px-4 py-2 rounded-full text-bakery-brown text-sm font-semibold mb-6">
              <Star className="w-4 h-4 fill-bakery-brown" />
              <span>Best Home Bakery in Town</span>
            </div>
            <h1 className="text-6xl md:text-7xl font-display leading-[1.1] mb-6 text-bakery-brown">
              Baking Moments of <span className="text-bakery-brown-light italic">Pure Joy</span>
            </h1>
            <p className="text-lg text-bakery-brown/70 mb-10 max-w-lg leading-relaxed">
              Handcrafted with love, our cakes and pastries are made using the finest ingredients. 
              From custom birthday cakes to daily sweet cravings, we've got you covered.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={onOrderClick}
                className="bakery-button flex items-center justify-center gap-2 text-lg group"
              >
                Order Your Cake
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="bakery-button-outline text-lg">
                View Menu
              </button>
            </div>
            
            <div className="mt-12 flex items-center gap-8">
              <div>
                <p className="text-3xl font-display font-bold text-bakery-brown">500+</p>
                <p className="text-sm text-bakery-brown/60">Happy Customers</p>
              </div>
              <div className="w-px h-12 bg-bakery-pink-dark" />
              <div>
                <p className="text-3xl font-display font-bold text-bakery-brown">50+</p>
                <p className="text-sm text-bakery-brown/60">Cake Designs</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white">
              <img 
                src="https://picsum.photos/seed/bakery-hero/800/1000" 
                alt="Delicious Cake" 
                className="w-full h-auto"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-bakery-pink rounded-full blur-3xl opacity-50" />
            <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-bakery-pink-dark rounded-full blur-3xl opacity-30" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
